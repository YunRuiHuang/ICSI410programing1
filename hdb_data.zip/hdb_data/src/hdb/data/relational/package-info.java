/**
 * Provides classes for representing relational data. 
 */
package hdb.data.relational;

