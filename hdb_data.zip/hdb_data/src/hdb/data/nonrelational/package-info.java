/**
 * Provides classes for representing non-relational data. 
 */
package hdb.data.nonrelational;

